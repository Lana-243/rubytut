class Movie
  attr_accessor :title, :director, :first_screening_year

  def initialize(title, director, first_screening_year)
    @title = title
    @director = director
    @first_screening_year = first_screening_year
  end
end
